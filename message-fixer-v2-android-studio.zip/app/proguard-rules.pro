# Message-Fixer V2 currently needs no custom ProGuard rules.
