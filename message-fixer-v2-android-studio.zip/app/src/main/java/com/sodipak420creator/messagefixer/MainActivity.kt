package com.sodipak420creator.messagefixer

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.Voice
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val emojis = listOf(
        "😀","😃","😂","🤣","😊","😍","🥰","😘",
        "😎","🤩","🥳","🤔","😐","🙄","😏","😴",
        "😱","😢","😭","😡","🤬","🤯","😈","👻",
        "💀","🤖","👽","🎃","❤️","🔥","💯","✨"
    )

    private var selectedEmoji = "😀"
    private var voices: List<Voice> = emptyList()
    private lateinit var tts: TtsEngine

    private lateinit var emojiPreview: TextView
    private lateinit var messageInput: EditText
    private lateinit var voiceSpinner: Spinner
    private lateinit var speedSeek: SeekBar
    private lateinit var pitchSeek: SeekBar
    private lateinit var speedValue: TextView
    private lateinit var pitchValue: TextView
    private lateinit var charCount: TextView
    private lateinit var emojiGrid: GridLayout
    private lateinit var savedList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        emojiPreview = findViewById(R.id.emojiPreview)
        messageInput = findViewById(R.id.messageInput)
        voiceSpinner = findViewById(R.id.voiceSpinner)
        speedSeek = findViewById(R.id.speedSeek)
        pitchSeek = findViewById(R.id.pitchSeek)
        speedValue = findViewById(R.id.speedValue)
        pitchValue = findViewById(R.id.pitchValue)
        charCount = findViewById(R.id.charCount)
        emojiGrid = findViewById(R.id.emojiGrid)
        savedList = findViewById(R.id.savedList)

        buildEmojiGrid()
        updateSliders()

        messageInput.addTextChangedListener(SimpleTextWatcher {
            charCount.text = "${messageInput.text.length}/500"
        })

        speedSeek.setOnSeekBarChangeListener(simpleSeek {
            updateSliders()
        })
        pitchSeek.setOnSeekBarChangeListener(simpleSeek {
            updateSliders()
        })

        findViewById<Button>(R.id.testSpeakButton).setOnClickListener {
            testSpeak()
        }

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            saveVoiceEmoji()
        }

        findViewById<Button>(R.id.keyboardSettingsButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        findViewById<Button>(R.id.switchKeyboardButton).setOnClickListener {
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .showInputMethodPicker()
        }

        tts = TtsEngine(this) { ready ->
            if (ready) {
                voices = tts.voices()
                populateVoices()
            } else {
                Toast.makeText(this, "Text-to-Speech is not available.", Toast.LENGTH_LONG).show()
            }
        }

        renderSaved()
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }

    private fun buildEmojiGrid() {
        emojiGrid.removeAllViews()
        emojis.forEach { emoji ->
            val button = Button(this).apply {
                text = emoji
                textSize = 24f
                setOnClickListener {
                    selectedEmoji = emoji
                    emojiPreview.text = emoji
                }
            }
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = 58.dp
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(3.dp, 3.dp, 3.dp, 3.dp)
            }
            emojiGrid.addView(button, params)
        }
    }

    private fun populateVoices() {
        val labels = voices.map {
            "${it.name} — ${it.locale.toLanguageTag()}" 
        }.ifEmpty { listOf("Default device voice") }

        voiceSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            labels
        )
    }

    private fun currentVoice(): Voice? {
        if (voices.isEmpty()) return null
        return voices.getOrNull(voiceSpinner.selectedItemPosition)
    }

    private fun currentRate(): Float =
        (0.5f + speedSeek.progress * 0.1f).coerceIn(0.5f, 2.0f)

    private fun currentPitch(): Float =
        (pitchSeek.progress * 0.1f).coerceIn(0.0f, 2.0f)

    private fun updateSliders() {
        speedValue.text = String.format(Locale.US, "%.1f×", currentRate())
        pitchValue.text = String.format(Locale.US, "%.1f", currentPitch())
    }

    private fun testSpeak() {
        val text = messageInput.text.toString().trim()
        if (text.isEmpty()) {
            messageInput.error = "Type something first"
            return
        }
        val voice = currentVoice()
        tts.speak(
            text,
            voice?.name,
            voice?.locale?.toLanguageTag(),
            currentRate(),
            currentPitch()
        )
    }

    private fun saveVoiceEmoji() {
        val text = messageInput.text.toString().trim()
        if (text.isEmpty()) {
            messageInput.error = "Type something first"
            return
        }

        val voice = currentVoice()
        val item = VoiceEmoji(
            id = System.currentTimeMillis(),
            emoji = selectedEmoji,
            text = text,
            voiceName = voice?.name ?: "",
            voiceLocale = voice?.locale?.toLanguageTag() ?: Locale.getDefault().toLanguageTag(),
            rate = currentRate(),
            pitch = currentPitch()
        )

        VoiceEmojiStore.save(this, item)
        renderSaved()

        Toast.makeText(
            this,
            "Saved! Open the Message-Fixer keyboard to use it.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun renderSaved() {
        savedList.removeAllViews()
        val items = VoiceEmojiStore.load(this)

        if (items.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No Voice Emojis saved yet."
                setTextColor(getColor(R.color.mf_muted))
                setPadding(0, 16.dp, 0, 16.dp)
            }
            savedList.addView(empty)
            return
        }

        items.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(8.dp, 10.dp, 8.dp, 10.dp)
                setBackgroundResource(R.drawable.card_bg)
            }

            val emoji = TextView(this).apply {
                text = item.emoji
                textSize = 36f
                gravity = android.view.Gravity.CENTER
            }

            val info = TextView(this).apply {
                text = item.text
                textSize = 15f
                setTextColor(getColor(R.color.mf_text))
                setPadding(12.dp, 0, 8.dp, 0)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val play = Button(this).apply {
                text = "▶"
                setOnClickListener { tts.speak(item) }
            }

            val delete = Button(this).apply {
                text = "×"
                setOnClickListener {
                    VoiceEmojiStore.delete(this@MainActivity, item.id)
                    renderSaved()
                }
            }

            row.addView(emoji, LinearLayout.LayoutParams(58.dp, 58.dp))
            row.addView(info)
            row.addView(play)
            row.addView(delete)

            val rowParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            rowParams.setMargins(0, 8.dp, 0, 0)
            savedList.addView(row, rowParams)
        }
    }

    private fun simpleSeek(action: () -> Unit) =
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = action()
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }

    private class SimpleTextWatcher(private val onChange: () -> Unit) :
        android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = onChange()
        override fun afterTextChanged(s: android.text.Editable?) {}
    }

    private val Int.dp: Int
        get() = (this * resources.displayMetrics.density).toInt()
}
