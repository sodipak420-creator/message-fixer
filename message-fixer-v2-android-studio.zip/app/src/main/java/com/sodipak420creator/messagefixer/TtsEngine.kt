package com.sodipak420creator.messagefixer

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.io.File
import java.util.Locale

class TtsEngine(
    context: Context,
    private val onReady: (Boolean) -> Unit
) : TextToSpeech.OnInitListener {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(appContext, this)
    }

    override fun onInit(status: Int) {
        onReady(status == TextToSpeech.SUCCESS)
    }

    fun voices(): List<Voice> =
        tts?.voices?.sortedWith(compareBy({ it.locale.toLanguageTag() }, { it.name }))
            ?: emptyList()

    fun setVoiceByName(name: String, localeTag: String) {
        val match = voices().firstOrNull {
            it.name == name && it.locale.toLanguageTag() == localeTag
        }
        if (match != null) tts?.voice = match
    }

    fun speak(item: VoiceEmoji) {
        val engine = tts ?: return
        setVoiceByName(item.voiceName, item.voiceLocale)
        engine.setSpeechRate(item.rate)
        engine.setPitch(item.pitch)
        engine.speak(
            item.text,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "voiceemoji_${item.id}"
        )
    }

    fun speak(text: String, voiceName: String?, localeTag: String?, rate: Float, pitch: Float) {
        val engine = tts ?: return
        if (!voiceName.isNullOrBlank()) {
            setVoiceByName(voiceName, localeTag ?: "")
        }
        engine.setSpeechRate(rate)
        engine.setPitch(pitch)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "preview")
    }

    fun synthesize(
        item: VoiceEmoji,
        file: File,
        onFinished: (Boolean) -> Unit
    ) {
        val engine = tts
        if (engine == null) {
            onFinished(false)
            return
        }

        setVoiceByName(item.voiceName, item.voiceLocale)
        engine.setSpeechRate(item.rate)
        engine.setPitch(item.pitch)

        val result = engine.synthesizeToFile(
            item.text,
            android.os.Bundle(),
            file,
            "file_${item.id}_${System.currentTimeMillis()}"
        )

        onFinished(result == TextToSpeech.SUCCESS)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
