package com.sodipak420creator.messagefixer

data class VoiceEmoji(
    val id: Long,
    val emoji: String,
    val text: String,
    val voiceName: String,
    val voiceLocale: String,
    val rate: Float,
    val pitch: Float
)
