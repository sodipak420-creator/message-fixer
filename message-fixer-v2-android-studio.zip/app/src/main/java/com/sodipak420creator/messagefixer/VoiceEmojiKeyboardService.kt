package com.sodipak420creator.messagefixer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.core.content.FileProvider
import android.inputmethodservice.InputMethodService
import java.io.File

class VoiceEmojiKeyboardService : InputMethodService() {

    private var selected: VoiceEmoji? = null
    private var tts: TtsEngine? = null

    override fun onCreate() {
        super.onCreate()
        tts = TtsEngine(this) { }
    }

    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.keyboard_view, null)

        val message = view.findViewById<EditText>(R.id.keyboardMessage)
        val row = view.findViewById<LinearLayout>(R.id.emojiRow)
        val empty = view.findViewById<TextView>(R.id.emptyKeyboard)

        val items = VoiceEmojiStore.load(this)

        if (items.isEmpty()) {
            empty.visibility = View.VISIBLE
        } else {
            empty.visibility = View.GONE
            items.forEach { item ->
                val button = Button(this).apply {
                    text = item.emoji
                    textSize = 27f
                    setOnClickListener {
                        selected = item
                        message.setText(item.text)
                        message.setSelection(message.text.length)
                    }
                }
                row.addView(
                    button,
                    LinearLayout.LayoutParams(58.dp, 58.dp)
                )
            }
        }

        view.findViewById<Button>(R.id.speakButton).setOnClickListener {
            val item = selected?.copy(text = message.text.toString().trim())
                ?: makeTemporaryItem(message)

            if (item.text.isBlank()) {
                Toast.makeText(this, "Type a message first.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            tts?.speak(item)
        }

        view.findViewById<Button>(R.id.sendButton).setOnClickListener {
            val item = selected?.copy(text = message.text.toString().trim())
                ?: makeTemporaryItem(message)

            if (item.text.isBlank()) {
                Toast.makeText(this, "Type a message first.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            createAndShareAudio(item)
        }

        view.findViewById<Button>(R.id.emojiOnlyButton).setOnClickListener {
            currentInputConnection?.commitText(selected?.emoji ?: "😀", 1)
        }

        view.findViewById<Button>(R.id.spaceButton).setOnClickListener {
            currentInputConnection?.commitText(" ", 1)
        }

        view.findViewById<Button>(R.id.enterButton).setOnClickListener {
            currentInputConnection?.sendKeyEvent(
                android.view.KeyEvent(
                    android.view.KeyEvent.ACTION_DOWN,
                    android.view.KeyEvent.KEYCODE_ENTER
                )
            )
            currentInputConnection?.sendKeyEvent(
                android.view.KeyEvent(
                    android.view.KeyEvent.ACTION_UP,
                    android.view.KeyEvent.KEYCODE_ENTER
                )
            )
        }

        view.findViewById<Button>(R.id.settingsButton).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }

        return view
    }

    private fun makeTemporaryItem(message: EditText): VoiceEmoji =
        VoiceEmoji(
            id = System.currentTimeMillis(),
            emoji = selected?.emoji ?: "😀",
            text = message.text.toString().trim(),
            voiceName = "",
            voiceLocale = "",
            rate = 1.0f,
            pitch = 1.0f
        )

    private fun createAndShareAudio(item: VoiceEmoji) {
        val folder = File(cacheDir, "voiceemoji").apply { mkdirs() }
        val file = File(folder, "voiceemoji_${item.id}_${System.currentTimeMillis()}.wav")

        tts?.synthesize(item, file) { queued ->
            if (!queued) {
                Toast.makeText(this, "Could not create audio.", Toast.LENGTH_SHORT).show()
                return@synthesize
            }

            // TTS synthesis is asynchronous. Poll briefly for the output file.
            waitForFile(file, 0)
        }
    }

    private fun waitForFile(file: File, attempt: Int) {
        if (file.exists() && file.length() > 100) {
            shareAudio(file)
            return
        }

        if (attempt >= 30) {
            Toast.makeText(this, "Audio creation timed out.", Toast.LENGTH_SHORT).show()
            return
        }

        android.os.Handler(mainLooper).postDelayed({
            waitForFile(file, attempt + 1)
        }, 200)
    }

    private fun shareAudio(file: File) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                this,
                "${packageName}.fileprovider",
                file
            )

            val share = Intent(Intent.ACTION_SEND).apply {
                type = "audio/wav"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "${selected?.emoji ?: "🎤"} Voice Emoji")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            startActivity(Intent.createChooser(share, "Send Voice Emoji"))
        } catch (e: Exception) {
            Toast.makeText(this, "No app can receive the Voice Emoji audio.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    private val Int.dp: Int
        get() = (this * resources.displayMetrics.density).toInt()
}
