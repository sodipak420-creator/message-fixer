package com.sodipak420creator.messagefixer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object VoiceEmojiStore {
    private const val PREFS = "voice_emoji_store"
    private const val KEY_ITEMS = "items"

    fun load(context: Context): MutableList<VoiceEmoji> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_ITEMS, "[]") ?: "[]"
        val result = mutableListOf<VoiceEmoji>()

        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                result.add(
                    VoiceEmoji(
                        id = o.optLong("id"),
                        emoji = o.optString("emoji"),
                        text = o.optString("text"),
                        voiceName = o.optString("voiceName"),
                        voiceLocale = o.optString("voiceLocale"),
                        rate = o.optDouble("rate", 1.0).toFloat(),
                        pitch = o.optDouble("pitch", 1.0).toFloat()
                    )
                )
            }
        } catch (_: Exception) {
        }

        return result
    }

    fun save(context: Context, item: VoiceEmoji) {
        val list = load(context)
        list.removeAll { it.id == item.id }
        list.add(0, item)
        write(context, list)
    }

    fun delete(context: Context, id: Long) {
        val list = load(context).filterNot { it.id == id }
        write(context, list)
    }

    fun clear(context: Context) {
        write(context, emptyList())
    }

    private fun write(context: Context, list: List<VoiceEmoji>) {
        val array = JSONArray()
        list.forEach { item ->
            array.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("emoji", item.emoji)
                    put("text", item.text)
                    put("voiceName", item.voiceName)
                    put("voiceLocale", item.voiceLocale)
                    put("rate", item.rate)
                    put("pitch", item.pitch)
                }
            )
        }

        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ITEMS, array.toString())
            .apply()
    }
}
