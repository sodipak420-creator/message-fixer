# 🎤 Message-Fixer — Voice Emoji V2

Version 2 turns Message-Fixer into an Android IME (keyboard).

## What it does

1. Open Message-Fixer.
2. Choose an emoji.
3. Type the sentence.
4. Choose an Android Text-to-Speech voice.
5. Adjust speed and pitch.
6. Tap **Save Voice Emoji to Keyboard**.
7. Tap **Enable Message-Fixer Keyboard**.
8. In Android settings, enable the keyboard.
9. Tap **Switch Keyboard** and select Message-Fixer.
10. Open a text app and use the Voice Emoji keyboard.

## Keyboard features

- Saved Voice Emoji buttons
- Select an emoji and load its saved message
- Play the Voice Emoji
- Insert the emoji itself into the current text field
- Send generated WAV audio through Android's share sheet
- Open the main app from the keyboard

## Important limitation

Android keyboards can insert text through the IME `InputConnection`. They cannot turn a Unicode emoji such as 😀 into a new universal audio-bearing Unicode character.

Therefore V2 uses two compatible actions:

- **Insert** = inserts the normal emoji into the current text field.
- **Send Audio** = generates a WAV Voice Emoji and opens Android's share sheet so the user can send the audio to an app that accepts audio attachments.

This is the practical first Android version. A future V3 could add a custom Voice Emoji package, cloud links, animated emojis, and receiving/decoding inside Message-Fixer.

## Build

Open this folder in Android Studio.

Use:
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- compileSdk 35
- minSdk 26
- Java 17

Android Studio will download the Gradle/Android dependencies.

Then:
**Build → Build APK(s)**

The debug APK will normally be:
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub

Recommended repository:
`message-fixer`

Replace the repository contents with this project or put the project in a new branch/folder.

## Privacy

V2 has no server, no account, and no API key.

Saved Voice Emoji definitions are stored locally in SharedPreferences. Audio generated for sharing is stored temporarily in the app cache.

Text-to-Speech voice availability depends on the TTS engines/voices installed on the Android device.

## Android IME architecture

The keyboard is an `InputMethodService`. Android exposes IMEs as system keyboards and gives them an `InputConnection` for committing text to the focused application.

Official Android documentation:
https://developer.android.com/develop/ui/views/touch-and-input/creating-input-method

Text-to-Speech can speak text and synthesize speech to a file:
https://developer.android.com/reference/android/speech/tts/TextToSpeech
